% Graphing Code:
% Author: Ketan Kamat
% Date of Submission: December 8th, 2019

%Maximum Fitness Scores imported
MaxStuff = csvread("/Users/ketankamat/Documents/FinalSubmission/MaxFitness.csv")';
%Raw Fitness Scores imported
RawStuff = csvread("/Users/ketankamat/Documents/FinalSubmission/RawFitness.csv");

%Extra Data Point from Raw Fitness Scores removed
RawStuff = RawStuff(1:end,1:200);

%Average Fitness Scores are found
AverageStuff = mean(RawStuff,2)';

%Time Vector Created
Time = (1:length(AverageStuff));

%DataSet 1 is plotted
plot(Time,AverageStuff);

%Hold on function is used
hold on

%DataSet 2 is plotted
plot(Time,MaxStuff);

%Adding Labels
title("Average Fitness Scores and Raw Fitness Scores against Time");
ylabel("Fitness Score");
xlabel("Number of Generations");
legend ("Average Fitness Score","Max Fitness Score");
