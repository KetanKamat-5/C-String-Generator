//-----------------------------------------------------------------------------
// CSCI1320 Course Project
// Author: Ketan Kamat
// Date of Submission: Dec 9th 2021
// Identification: FinalProjectKetanKamat.cpp
//-----------------------------------------------------------------------------
#include<iostream>
#include<string>
#include<ctime>
#include<cmath>
#include<fstream>
using namespace std;

// Function declarations

// Prototype of the buildPopulation function
void buildPopulation(int length, int NumsArray1[], int NumsArray2[],int populationsize,string population[], char targetarray[]);
// Prototype of the Calculatefitness function
void calculateFitness(string population[],double scorearray[],double scorearrray2[] ,string target,int populationsize, double& fitness, int matingfactor, int length);
// Prototype of the buildMatingpool function
void buildMatingPool (double scorearray2[],double rafflearray[],int& sum, int populationsize);
// Prototype of the breeding function
void breeding (string population[], double rafflearray[], int populationsize, int length, string breedarray[], int sum);
// Prototype of the the mutation function
void causeMutation (string population[], string breedarray[], int populationsize, int length, int mutationrate);

int main () {
 ofstream RawFitness("RawFitness.csv",ios::out);
 ofstream MaxFitness("MaxFitness.csv",ios::out);
srand(time(NULL));
// Define the target phrase
string target;
// Prompt the user for the target phrase
cout<<"Please enter your target phrase"<<endl;
// User enters phrase
getline(cin,target);
// Define length of phrase
int length = target.size();
// Declare population size
int populationsize;
// Declare mutation rate
int mutationrate;
// Prompt the user for the population size
cout<<"Please enter your population size (10000-50000 recommended)"<<endl;
// User enters population size
cin>>populationsize;
// Define mating factor
int matingfactor;
// Prompt user for mating factor
cout<<"Please enter the mating factor (4 is recommended)"<<endl;
// User enters mating factor
cin>>matingfactor;
// Prompt user for mutation rate
cout<<"Please enter the mutation rate (2 is recommended)"<<endl;
// User enters mutation rate
cin>>mutationrate;
//Set of integers which will be converted to characters and form strings
int NumsArray1 [53] = {32,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122};
// Second set of integers which will be used to form phrase
int NumsArray2[length];
// String array containing population of 200 strings
string population[populationsize];
// Character array containing characters randomly chosen
char targetarray[length];
// String array containing breeded children
string breedarray[populationsize];
// function call for buildpopulation
buildPopulation(length,NumsArray1,NumsArray2,populationsize,population,targetarray);
// double array that contains raw fitness scores
double scorearray[populationsize];
// double array that contains rounded fitness scores
double scorearray2[populationsize];
// double variable called fitness
double fitness;
// double array which will build mating pool
double rafflearray[populationsize*matingfactor];
// function call for calculateFitness
calculateFitness(population,scorearray,scorearray2,target,populationsize,fitness,matingfactor,length);
// declaration of integer sum
int sum;
// function call for buildMatingpool
buildMatingPool(scorearray2,rafflearray,sum,populationsize);
//function call for breeding
breeding(population,rafflearray,populationsize,length,breedarray,sum);
// function call for causeMutation
causeMutation(population,breedarray,populationsize,length,mutationrate);
// string with highest fitness score
string word;
// integer that will calculate number of iterations
int count = 0;
// highest raw fitness score
double maxnumber;
// while loop which will continue iterating until the target phrase is reached
while(maxnumber!=1 && count<10000){
// An assumption is made that the highest raw fitness score is in first position
maxnumber = scorearray[0];
// calculateFitness function call
calculateFitness(population,scorearray,scorearray2,target,populationsize,fitness,matingfactor,length);
// For loop finding the maximum raw fitness score and coressponding string
for (int i=0;i<=199;i++) {
if (scorearray[i]>maxnumber) {
maxnumber = scorearray[i];
word = population[i];
}
}
// buildMatingPool function call
buildMatingPool (scorearray2,rafflearray,sum,populationsize);
// breeding function call
breeding(population,rafflearray,populationsize,length,breedarray,sum);
// causeMutation function call
causeMutation(population,breedarray,populationsize,length,mutationrate);
//count is incremented by one each time
count++;
// Displaying contents of each variable
cout<<"The fitness score is "<<maxnumber<<"and the string is"<<" "<<word<<" "<<"And the iteration is"<< " "<<count<<endl;
for (int w=0;w<populationsize;w++) {
 RawFitness<<scorearray[w]<<",";
 }
RawFitness<<"\n";
 MaxFitness<<maxnumber<<"\n";
}
 RawFitness.close();
 MaxFitness.close();
return 0;
}




// buildPopulation function definition
//input: length, NumsArray1[], NumsArray2[], populationsize, population[], targetarray[]
//output:void
void buildPopulation(int length, int NumsArray1[], int NumsArray2[],int populationsize,string population[],char targetarray[]) 
{
//Nested for loop which will form population of 200 strings
for (int a=0;a<=populationsize-1;a++) {
for (int b=0;b<=length-1;b++) {
int c =rand()%53;
NumsArray2[b] =NumsArray1[c];
targetarray[b] = NumsArray2[b];
population[a]+=targetarray[b];
}
}
}

// calculateFitness function definition
//input:  population[], scorearray[], scorearray2[], target, populationsize, fitness, matingfactor, length
//output: void
void calculateFitness (string population[],double scorearray[],double scorearray2[],string target, int populationsize, double& fitness, int matingfactor, int length)
{
// Nested for loops and if loops which calculate  the raw fitness score  
for (int e=0;e<=populationsize-1;e++) {
double count = 0;
string string1 = population[e];
for (int f=0;f<=length-1;f++) {
string string2 = string1.substr(f,1);
if (string2==target.substr(f,1)) {
count++;
}
}
fitness = (count/length);
scorearray[e] = pow(fitness,1);
}
// Equating scorearray3 to scorearray
double scorearray3[populationsize];
for (int f=0;f<=populationsize-1;f++) {
scorearray3[f]= scorearray[f]*100;
}
//make an assumption that maximum score is in first position
double max = scorearray3[0];
// Find the max score in the scorearray
for (int h=0;h<=populationsize-1;h++) {
if (scorearray3[h]>max) {
max = scorearray3[h];
}
}
// Normalize the fitness scores
for (int j=0; j<=populationsize-1; j++) {
scorearray2[j] = scorearray3[j]/max;
}
// Calculate the rounded fitness scores
for (int k=0; k<=populationsize-1; k++) {
scorearray2[k]*=matingfactor;
scorearray2[k]= round(scorearray2[k]);
}
}



// buildMatingPool function definition
// input: scorearray2[],rafflearray[],sum,populationsize
// output: void
void buildMatingPool(double scorearray2[],double rafflearray[],int& sum, int populationsize) {
// sum is intialized with a value of zero 
sum=0;
// Finding sum of rounded fitness scores
for (int p=0;p<=populationsize-1;p++) {
sum+=scorearray2[p];
}
// Index is given an initial value of zero
int index=0;
// Rafle array is created
for (int m=0;m<=populationsize-1;m++) {
for (int n=0;n<scorearray2[m];n++) {
rafflearray[index]=m;
index++;
}
}
}
 

// breed function definition
// input: population[], rafflearray[], populationsize, length, breedarray[], sum
// output: void
void breeding(string population[],double rafflearray[], int populationsize, int length, string breedarray[], int sum)  
{
// raffle array is converted from a double  array to an integer array
for(int y=0;y<sum;y++){
rafflearray[y]= (int) rafflearray[y];
}
//METHOD 1: CHOOSING A MIDPOINT
for (int q=0;q<=populationsize-1;q++) {
int r =rand()%sum;
int u =rafflearray[r];
string str1 = population[u];
int x = rand()%length;
// First half comes from str1
string half1 = str1.substr(0,x);
 int r2;
 do {
r2 = rand()%sum;} while (r2==r);
int u2= rafflearray[r2];
string str2 = population[u2];
// Second string comes from str2
string half2 =str2.substr(x,length-x);
// The two halves are combined
half1+=half2;
breedarray[q] = half1;
}

// METHOD 2: CHOOSING RANDOM LETTERS IN ONE STRING AND THE OPPOSITE IN THE OTHER
// for (int w=0;w<=populationsize-1;w++) {
// int r =rand()%sum;
// int u =rafflearray[r];
// //Retrieving first string from population
// string str1 =population[u];
// int r2 = rand()%sum;
// do{
// r2 = rand()%sum;
// } while(r==r2);
// int u2 = rafflearray[r2];
// // Retrieving second string population
// string str6 = population[u2];
// // Random number of characters will come from first string and replace second string
// int g = rand()%length;
// for (int a=0;a<g;a++) {
// int b = rand()%length;
// char char1 = str1[b];
// str6[b] = char1;
// }
// // Second string is placed inside breedarray
// breedarray[w] = str6;
// }
}

//causeMutation function definition
// input: population[],breedarray[], populationsize, length, mutationrate
// output: void
void causeMutation (string population[],string breedarray[],int populationsize,int length, int mutationrate) 
{
//Array of integers which shall then be converted to characters
int NumsArray1 [53] = {32,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122};
// The nested for and if loops go through the breedarray and mutate only certain strings
for (int s=0; s<=populationsize-1;s++) {
string str1 = breedarray[s];
int x = rand()%100;
if (x<=mutationrate-1) {
int y = rand()%53;
int z  = NumsArray1[y];
char c;
c = z;
string str2=str1;
int i = rand()%length;
str2[i]=c;
breedarray[s] = str2;
}
}
// The breedarray is then converted to the population array
for (int k=0;k<=populationsize-1;k++) {
population[k]=breedarray[k];
}
}

