<img src="https://www.colorado.edu/cs/profiles/express/themes/ucb/images/cu-boulder-logo-text-black.svg" alt="CU Boulder Logo" width="500">

# CSCI 1320: <br/> University Courses Database Project

# Author: Ketan Kamat
# Date of Submission: 12/6/2021

This was my final project for CSCI 1320 (Computer Science 1: Starting Computing-Engineering Applications). The objective of the project was to code a string generator given a specific algorithm that can re-generate a phrase provided by the user. The mating factor/mutation rate inputted by the user are crucial to the success of the algorithm and must be appropriate values in order for the algorithm to be effective.

My code perfectly matched the expected output of the test cases provided in an appropriate time frame.